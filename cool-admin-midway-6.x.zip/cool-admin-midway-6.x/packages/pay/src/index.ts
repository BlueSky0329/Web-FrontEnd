export { CoolPayConfiguration as Configuration } from './configuration';

export * from './interface';

export * from './wx';

export * from './ali';
