export const customKey = {
  a: 1,
  b: 'hello',
};
