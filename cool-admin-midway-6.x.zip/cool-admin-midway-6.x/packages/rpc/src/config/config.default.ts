/**
 * cool的配置
 */
export default {
  cool: {},
};
