export class CoolCloudUtil {}
