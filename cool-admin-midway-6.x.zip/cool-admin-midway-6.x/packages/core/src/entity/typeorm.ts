import { BaseEntity } from "typeorm";

export abstract class CoolBaseEntity extends BaseEntity {}
