
-- ----------------------------
-- Records of space_info
-- ----------------------------
BEGIN;
INSERT INTO `space_info` VALUES (1, '2023-02-13 21:34:09.746000', '2023-02-13 21:34:09.746000', 'http://127.0.0.1:8001/public/uploads/20230213/cc2c0b77-be51-4816-800f-ca48c61a08d6_1.pdf', 'file', NULL, '', '', 0, 1, '');
INSERT INTO `space_info` VALUES (2, '2023-02-14 19:35:32.492000', '2023-02-14 19:35:32.492000', 'http://127.0.0.1:8001/public/uploads/20230214/新建 PPTX 演示文稿.pptx', 'Presentation', NULL, '1676374532437', '新建 PPTX 演示文稿.pptx', 28708, 1, '');
INSERT INTO `space_info` VALUES (3, '2023-02-14 19:38:50.277000', '2023-02-14 19:38:50.277000', 'http://127.0.0.1:8001/public/uploads/20230214/1666245309333.jpg', 'image', NULL, '1676374730220', 'blob:http://localhost:9000/a17db32d-9b87-444f-aafb-7c77e788ddcd', 173693, 1, '');
INSERT INTO `space_info` VALUES (4, '2023-02-14 19:38:53.023000', '2023-02-14 19:38:53.023000', 'http://127.0.0.1:8001/public/uploads/20230214/1666245279343.jpg', 'image', NULL, '1676374732986', 'blob:http://localhost:9000/d447b62e-9ba1-4e22-8419-2024488c67e1', 237832, 1, '');
INSERT INTO `space_info` VALUES (5, '2023-02-14 19:38:56.646000', '2023-02-14 19:38:56.646000', 'http://127.0.0.1:8001/public/uploads/20230214/logo.zip', 'file', NULL, '1676374736602', 'logo.zip', 5560, 1, '');
INSERT INTO `space_info` VALUES (6, '2023-02-14 19:39:14.344000', '2023-02-14 19:39:14.344000', 'http://127.0.0.1:8001/public/uploads/20230214/2.png', 'image', NULL, '1676374754220', 'blob:http://localhost:9000/7a9cd28c-16d7-4b31-8d6d-970a83912ab1', 86861, 1, '');
INSERT INTO `space_info` VALUES (11, '2023-02-15 11:04:55.404000', '2023-02-15 11:04:55.404000', 'http://127.0.0.1:8001/public/uploads/20230215/8f8f4d6a847f0491e613e586f51c57b1.mp4', 'video', NULL, '1676430295322', '8f8f4d6a847f0491e613e586f51c57b1.mp4', 2264263, 1, '');
INSERT INTO `space_info` VALUES (12, '2023-02-15 11:05:57.352000', '2023-02-15 11:05:57.352000', 'http://127.0.0.1:8001/public/uploads/20230215/b7ab586ce4122241610be88cade1729e.mp4', 'video', NULL, '1676430357299', 'b7ab586ce4122241610be88cade1729e.mp4', 2200980, 1, '');
INSERT INTO `space_info` VALUES (13, '2023-02-15 11:13:11.986000', '2023-02-15 11:13:11.986000', 'http://127.0.0.1:8001/public/uploads/20230215/新建 文本文档.txt', 'file', NULL, '1676430791940', '新建 文本文档.txt', 0, 1, '');
INSERT INTO `space_info` VALUES (14, '2023-02-15 13:14:47.097000', '2023-02-15 13:14:47.097000', 'http://127.0.0.1:8001/public/uploads/20230215/logo.jpg', 'image', NULL, '1676438087053', 'blob:http://localhost:9000/2606eb20-9a24-4c46-abd5-cd364dda7b34', 7000, 1, '');
INSERT INTO `space_info` VALUES (37, '2023-02-16 21:38:24.004000', '2023-02-16 21:38:24.004000', 'http://127.0.0.1:8001/public/uploads/20230216/1666245279343.jpg', 'image', 1, '1676554703912', 'blob:http://localhost:9000/7b56eef2-2210-4a8e-b292-0f0e96738613', 237832, 1, '');
INSERT INTO `space_info` VALUES (38, '2023-02-16 21:38:24.018000', '2023-02-16 21:38:24.018000', 'http://127.0.0.1:8001/public/uploads/20230216/8f8f4d6a847f0491e613e586f51c57b1.mp4', 'video', 1, '1676554703910', '8f8f4d6a847f0491e613e586f51c57b1.mp4', 2264263, 1, '');
INSERT INTO `space_info` VALUES (39, '2023-02-16 21:38:24.037000', '2023-02-16 21:38:24.037000', 'http://127.0.0.1:8001/public/uploads/20230216/1666245309333.jpg', 'image', 1, '1676554703914', 'blob:http://localhost:9000/863f070d-df1c-4b73-8e1c-cb0344ef7a47', 173693, 1, '');
INSERT INTO `space_info` VALUES (40, '2023-02-16 21:38:24.054000', '2023-02-16 21:38:24.054000', 'http://127.0.0.1:8001/public/uploads/20230216/logo.jpg', 'image', 1, '1676554703917', 'blob:http://localhost:9000/66b0c6d4-9525-44a2-b48d-33456bcbdce1', 7000, 1, '');
INSERT INTO `space_info` VALUES (41, '2023-02-16 21:38:24.058000', '2023-02-16 21:38:24.058000', 'http://127.0.0.1:8001/public/uploads/20230216/b7ab586ce4122241610be88cade1729e.mp4', 'video', 1, '1676554703916', 'b7ab586ce4122241610be88cade1729e.mp4', 2200980, 1, '');
INSERT INTO `space_info` VALUES (42, '2023-02-16 21:40:47.400000', '2023-02-16 21:40:47.400000', 'http://127.0.0.1:8001/public/uploads/20230216/logo.jpg', 'image', 1, '1676554847357', 'blob:http://localhost:9000/cae13036-927e-44fb-942b-58f2d5833191', 7000, 1, '');
INSERT INTO `space_info` VALUES (43, '2023-02-16 21:40:50.514000', '2023-02-16 21:40:50.514000', 'http://127.0.0.1:8001/public/uploads/20230216/1666245309333.jpg', 'image', 1, '1676554850474', 'blob:http://localhost:9000/0f2e7c13-d23c-4a59-a84b-b7318ac43df1', 173693, 1, '');
INSERT INTO `space_info` VALUES (45, '2023-02-16 21:43:06.102000', '2023-02-16 21:43:06.102000', 'http://127.0.0.1:8001/public/uploads/20230216/logo.zip', 'file', 1, '1676554986059', 'logo.zip', 5560, 1, '');
INSERT INTO `space_info` VALUES (46, '2023-02-16 21:45:54.201000', '2023-02-16 21:45:54.201000', 'http://127.0.0.1:8001/public/uploads/20230216/新建 PPTX 演示文稿.pptx', 'Presentation', 1, '1676555154159', '新建 PPTX 演示文稿.pptx', 28708, 1, '');
INSERT INTO `space_info` VALUES (47, '2023-02-16 21:48:02.552000', '2023-02-16 21:48:02.552000', 'http://127.0.0.1:8001/public/uploads/20230216/8f8f4d6a847f0491e613e586f51c57b1.mp4', 'video', 1, '1676555282502', '8f8f4d6a847f0491e613e586f51c57b1.mp4', 2264263, 1, '');
INSERT INTO `space_info` VALUES (48, '2023-02-17 19:43:48.707000', '2023-02-17 19:43:48.707000', 'http://127.0.0.1:8001/public/uploads/20230217/logo.png', 'image', 1, '1676634229583', 'blob:http://localhost:9000/a1c8d351-ff36-47b2-b477-fbb5de61e163', 8093, 1, '');
INSERT INTO `space_info` VALUES (49, '2023-02-17 19:45:05.837000', '2023-02-17 19:45:05.837000', 'http://127.0.0.1:8001/public/uploads/20230217/logo.png', 'image', 1, '1676634305795', 'blob:http://localhost:9000/36659fd0-7bff-4a8a-b064-3f9ba6530191', 8093, 1, '');
INSERT INTO `space_info` VALUES (50, '2023-02-17 19:46:36.423000', '2023-02-17 19:46:36.423000', 'http://127.0.0.1:8001/public/uploads/20230217/c8128c24-d0e9-4e07-9c0d-6f65446e105b.png', 'image', 1, '1676634396368', 'blob:http://localhost:9000/ac931705-c383-47b0-8542-e12f2eba1a55', 3313, 1, '');
INSERT INTO `space_info` VALUES (51, '2023-02-19 23:41:21.326000', '2023-02-19 23:41:21.326000', 'http://127.0.0.1:8001/public/uploads/20230219/图层4.png', 'image', 1, '1676821281209', 'blob:http://localhost:9000/d9ddbe89-b206-4766-a4dc-7df1032bfe39', 357586, 1, '');
INSERT INTO `space_info` VALUES (52, '2023-02-19 23:41:53.150000', '2023-02-19 23:41:53.150000', 'http://127.0.0.1:8001/public/uploads/20230219/1669607797795096.mp4', 'video', 1, '1676821312901', '1669607797795096.mp4', 15929928, 1, '');
INSERT INTO `space_info` VALUES (86, '2023-03-06 20:23:22.467000', '2023-03-08 15:10:05.822205', 'https://show.cool-admin.com/api/public/uploads/20230306/e023a2e79ba643e486310e0e56adbb8b_1666245279343.jpg', 'image', 10, 'e023a2e79ba643e486310e0e56adbb8b', 'blob:https://show.cool-admin.com/ec7b723d-e228-4b22-840d-da0da388aa09', 237832, 1, '/public/uploads/20230306/e023a2e79ba643e486310e0e56adbb8b_1666245279343.jpg');
INSERT INTO `space_info` VALUES (87, '2023-03-06 20:23:22.501000', '2023-03-08 15:10:09.746789', 'https://show.cool-admin.com/api/public/uploads/20230306/7700e5c10b74484097eb6ba80882da4d_1666245309333.jpg', 'image', 10, '7700e5c10b74484097eb6ba80882da4d', 'blob:https://show.cool-admin.com/1588f52f-a3a8-44ed-9387-a9f7e3cacf6d', 173693, 1, '/public/uploads/20230306/7700e5c10b74484097eb6ba80882da4d_1666245309333.jpg');
INSERT INTO `space_info` VALUES (99, '2023-03-08 14:11:15.452000', '2023-03-08 15:10:12.252268', 'https://show.cool-admin.com/api/public/uploads/20230308/c731b0cba84046268b10edbbcf36f948_315c243a448e1369fa145c5ea3f020da.gif', 'image', 9, 'c731b0cba84046268b10edbbcf36f948', 'blob:https://show.cool-admin.com/ed25dee3-cbc5-4dcc-919c-7a3fb0b1af99', 331788, 1, '/public/uploads/20230308/c731b0cba84046268b10edbbcf36f948_315c243a448e1369fa145c5ea3f020da.gif');
INSERT INTO `space_info` VALUES (100, '2023-03-08 14:14:50.849000', '2023-03-08 14:21:46.000000', 'https://show.cool-admin.com/api/public/uploads/20230308/f182d2aa3bed4bff85c815dedc9155b1_演示ppt.pptx', 'Presentation', 14, 'f182d2aa3bed4bff85c815dedc9155b1', '演示ppt.pptx', 38865, 3, '/public/uploads/20230308/f182d2aa3bed4bff85c815dedc9155b1_演示ppt.pptx');
INSERT INTO `space_info` VALUES (101, '2023-03-08 14:14:50.871000', '2023-03-08 15:10:17.702950', 'https://show.cool-admin.com/api/public/uploads/20230308/02b08312cb654650853c078289873c84_演示表格.xlsx', 'Spreadsheet', 14, '02b08312cb654650853c078289873c84', '演示表格.xlsx', 8686, 1, '/public/uploads/20230308/02b08312cb654650853c078289873c84_演示表格.xlsx');
INSERT INTO `space_info` VALUES (102, '2023-03-08 14:14:50.900000', '2023-03-08 15:10:21.792369', 'https://show.cool-admin.com/api/public/uploads/20230308/fff47e95a8794073af5a1b90aabb5d52_演示word.docx', 'Writer', 14, 'fff47e95a8794073af5a1b90aabb5d52', '演示word.docx', 10064, 1, '/public/uploads/20230308/fff47e95a8794073af5a1b90aabb5d52_演示word.docx');
COMMIT;

-- ----------------------------
-- Records of space_type
-- ----------------------------
BEGIN;
INSERT INTO `space_type` VALUES (9, '2023-02-20 10:55:27.239000', '2023-02-20 10:55:43.302000', '微信头像', NULL);
INSERT INTO `space_type` VALUES (10, '2023-02-20 10:55:51.028000', '2023-02-20 10:55:51.028000', '朋友圈素材', NULL);
INSERT INTO `space_type` VALUES (11, '2023-02-20 10:56:23.866000', '2023-02-20 10:56:23.866000', '抖音视频', NULL);
INSERT INTO `space_type` VALUES (14, '2023-03-06 20:22:20.288000', '2023-03-06 20:22:20.288000', '文档', NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
