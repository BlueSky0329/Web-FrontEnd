export let Declares = ``;

export function addDeclare(content: string) {
	Declares += content;
}
