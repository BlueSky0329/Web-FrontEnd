import { ModuleConfig } from "/@/cool";

export default (): ModuleConfig => {
	return {};
};
