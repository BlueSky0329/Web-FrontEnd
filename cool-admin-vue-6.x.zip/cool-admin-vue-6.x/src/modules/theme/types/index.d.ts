export declare interface Theme {
	color?: string;
	name?: string;
	isGroup?: boolean;
	transition?: string;
}
