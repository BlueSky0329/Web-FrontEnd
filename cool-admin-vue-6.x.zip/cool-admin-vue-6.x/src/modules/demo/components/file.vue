<template>
	<div class="scope">
		<div class="h">
			<span>file</span>
			文件管理
		</div>
		<div class="c">
			<router-link to="/upload/list">传送门</router-link>
		</div>
		<div class="f">
			<span class="date">2023/01/01</span>
		</div>
	</div>
</template>
