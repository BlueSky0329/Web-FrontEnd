<template>
	<div class="scope">
		<div class="h">
			<span>cl-form</span>
			很强的表单
		</div>
		<div class="c">
			<form-btn />
		</div>
		<div class="f">
			<span class="date">2019/01/01</span>
		</div>
	</div>
</template>

<script lang="ts" setup>
import FormBtn from "./form-btn.vue";
</script>
