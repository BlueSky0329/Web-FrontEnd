<template>
	<div class="scope">
		<div class="h">
			<span>design-page</span>
			页面设计
		</div>
		<div class="c">
			<router-link to="/design/page">传送门</router-link>
		</div>
		<div class="f">
			<span class="date">2023/02/01</span>
		</div>
	</div>
</template>
