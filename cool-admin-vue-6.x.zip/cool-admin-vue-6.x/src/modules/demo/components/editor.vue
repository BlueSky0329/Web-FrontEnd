<template>
	<div class="scope">
		<div class="h">
			<span>cl-editor</span>
			编辑器
		</div>
		<div class="c">
			<router-link to="/demo/editor">传送门</router-link>
		</div>
		<div class="f">
			<span class="date">2019/11/07</span>
		</div>
	</div>
</template>
