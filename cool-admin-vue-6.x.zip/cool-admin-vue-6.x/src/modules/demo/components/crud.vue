<template>
	<div class="scope">
		<div class="h">
			<span>cl-crud</span>
			增删改查，超快的
		</div>
		<div class="c">
			<router-link to="/demo/crud">传送门</router-link>
		</div>
		<div class="f">
			<span class="date">2019/09/25</span>
		</div>
	</div>
</template>
