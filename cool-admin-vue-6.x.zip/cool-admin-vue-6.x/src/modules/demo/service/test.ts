import { BaseService, Service } from "/@/cool";

@Service("test")
class Test extends BaseService {}

export default Test;
