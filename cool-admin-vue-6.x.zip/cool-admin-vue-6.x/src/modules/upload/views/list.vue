<template>
	<space-inner />
</template>

<script lang="ts" setup name="upload-list">
import SpaceInner from "../components/space-inner.vue";
</script>
