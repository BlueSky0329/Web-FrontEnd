/// <reference types="@cool-vue/crud" />
/// <reference types="../build/cool/temp/eps" />

declare const __EPS__: string;
declare const __MODULE_DIRS__: string[];
