import { App } from "vue";
export declare const components: {
    [key: string]: any;
};
export declare function useComponent(app: App): void;
