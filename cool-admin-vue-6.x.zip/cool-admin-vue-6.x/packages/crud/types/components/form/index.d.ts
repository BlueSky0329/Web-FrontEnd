declare const _default: import("vue").DefineComponent<{
    inner: BooleanConstructor;
    inline: BooleanConstructor;
    customClass: StringConstructor;
}, () => false | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    inner: BooleanConstructor;
    inline: BooleanConstructor;
    customClass: StringConstructor;
}>>, {
    inner: boolean;
    inline: boolean;
}>;
export default _default;
