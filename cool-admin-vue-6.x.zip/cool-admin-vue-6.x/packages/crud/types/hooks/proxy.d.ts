export declare function useProxy(ctx: any): any;
