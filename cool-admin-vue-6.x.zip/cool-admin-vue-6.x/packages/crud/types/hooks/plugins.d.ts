/// <reference types="../index" />
/**
 * 设置聚焦，prop为空则默认第一个选项
 * @param prop
 * @returns
 */
export declare function setFocus(prop?: string): ClForm.Plugin;
