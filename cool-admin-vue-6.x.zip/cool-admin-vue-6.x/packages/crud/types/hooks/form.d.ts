export declare const format: any;
declare const _default: {
    bind(data: any): any;
    submit(data: any): any;
};
export default _default;
