import { App } from "vue";
declare const _default: {
    readonly vue: App<any>;
    get(key: string): any;
    set(key: string, value: any): void;
};
export default _default;
