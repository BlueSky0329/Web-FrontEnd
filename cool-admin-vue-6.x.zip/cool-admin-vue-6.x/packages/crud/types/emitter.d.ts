/// <reference types="../index" />
export declare const crudList: ClCrud.Ref[];
export declare const emitter: Emitter;
