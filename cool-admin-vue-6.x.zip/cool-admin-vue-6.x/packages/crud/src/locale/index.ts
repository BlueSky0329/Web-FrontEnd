import en from "./en";
import zhCn from "./zh-cn";

export const locale = {
	en,
	zhCn
};
