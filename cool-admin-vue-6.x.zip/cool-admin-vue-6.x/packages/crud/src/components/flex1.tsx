import { defineComponent } from "vue";

export default defineComponent({
	name: "cl-flex1",

	setup() {
		return () => {
			return <div class="cl-flex1" />;
		};
	}
});
